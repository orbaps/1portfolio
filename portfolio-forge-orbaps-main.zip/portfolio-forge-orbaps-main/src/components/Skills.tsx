
export const Skills = () => {
  const skillCategories = [
    {
      title: "Space & Defence",
      skills: [
        { name: "SOLIDWORKS CAD", level: 95 },
        { name: "Aerospace Engineering", level: 85 },
        { name: "Space Technology", level: 88 },
        { name: "Defence Systems", level: 82 },
        { name: "3D Printing & Prototyping", level: 90 },
      ]
    },
    {
      title: "Electronics & VLSI",
      skills: [
        { name: "VLSI Design", level: 88 },
        { name: "Circuit Analysis", level: 85 },
        { name: "PCB Design", level: 82 },
        { name: "Embedded Systems", level: 80 },
        { name: "Digital Signal Processing", level: 78 },
      ]
    },
    {
      title: "Frontend Development",
      skills: [
        { name: "React", level: 95 },
        { name: "TypeScript", level: 90 },
        { name: "Tailwind CSS", level: 92 },
        { name: "Vue.js", level: 85 },
        { name: "Three.js", level: 80 },
      ]
    },
    {
      title: "Backend & AI",
      skills: [
        { name: "Node.js", level: 88 },
        { name: "Python", level: 90 },
        { name: "TensorFlow", level: 85 },
        { name: "FastAPI", level: 82 },
        { name: "PostgreSQL", level: 80 },
      ]
    }
  ];

  return (
    <section id="skills" className="py-20 px-4 bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-sm">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4 font-playfair">Skills & Expertise</h2>
          <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-purple-600 mx-auto mb-4"></div>
          <p className="text-slate-300 text-lg max-w-2xl mx-auto font-inter">
            A comprehensive blend of space technology, VLSI electronics, defence systems, and modern web development
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {skillCategories.map((category, index) => (
            <div key={index} className="bg-slate-900/70 rounded-xl p-6 border border-slate-700/50 backdrop-blur-lg hover:border-blue-500/50 transition-all duration-500 transform hover:-translate-y-3 hover:shadow-2xl hover:shadow-blue-500/20">
              <h3 className="text-xl font-semibold text-white mb-6 text-center flex items-center justify-center font-playfair">
                <span className={`w-3 h-3 rounded-full mr-3 animate-pulse shadow-lg ${
                  index === 0 ? 'bg-yellow-500 shadow-yellow-500/50' : 
                  index === 1 ? 'bg-green-500 shadow-green-500/50' : 
                  index === 2 ? 'bg-blue-500 shadow-blue-500/50' : 'bg-purple-500 shadow-purple-500/50'
                }`}></span>
                {category.title}
              </h3>
              <div className="space-y-4">
                {category.skills.map((skill, skillIndex) => (
                  <div key={skillIndex} className="group">
                    <div className="flex justify-between mb-2">
                      <span className="text-slate-300 text-sm font-medium font-inter">{skill.name}</span>
                      <span className="text-blue-400 text-sm font-bold">{skill.level}%</span>
                    </div>
                    <div className="w-full bg-slate-700/50 rounded-full h-2.5 overflow-hidden backdrop-blur-sm">
                      <div 
                        className={`h-2.5 rounded-full transition-all duration-1000 ease-out group-hover:shadow-lg ${
                          index === 0 ? 'bg-gradient-to-r from-yellow-500 to-orange-600 shadow-yellow-500/50' : 
                          index === 1 ? 'bg-gradient-to-r from-green-500 to-emerald-600 shadow-green-500/50' : 
                          index === 2 ? 'bg-gradient-to-r from-blue-500 to-cyan-600 shadow-blue-500/50' : 
                          'bg-gradient-to-r from-purple-500 to-pink-600 shadow-purple-500/50'
                        }`}
                        style={{ width: `${skill.level}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Enhanced Certifications Section */}
        <div className="mt-16 text-center">
          <h3 className="text-2xl font-semibold text-white mb-8 font-playfair">Certifications & Achievements</h3>
          <div className="flex flex-wrap justify-center gap-6">
            <div className="bg-gradient-to-r from-yellow-500 to-orange-600 text-black px-8 py-4 rounded-full font-bold animate-pulse shadow-xl hover:scale-105 transition-transform duration-300">
              <span className="text-xl mr-2">🏆</span>
              SOLIDWORKS CAD Design Associate (CSWA)
            </div>
            <div className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-8 py-4 rounded-full font-bold shadow-xl hover:scale-105 transition-transform duration-300">
              <span className="text-xl mr-2">🚀</span>
              Indian Space Labs - Ex-Intern
            </div>
            <div className="bg-gradient-to-r from-green-500 to-blue-600 text-white px-8 py-4 rounded-full font-bold shadow-xl hover:scale-105 transition-transform duration-300">
              <span className="text-xl mr-2">🎓</span>
              B.Tech Electronics (VLSI) - RRU
            </div>
            <div className="bg-gradient-to-r from-purple-500 to-pink-600 text-white px-8 py-4 rounded-full font-bold shadow-xl hover:scale-105 transition-transform duration-300">
              <span className="text-xl mr-2">🖨️</span>
              3D Printing Specialist
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
