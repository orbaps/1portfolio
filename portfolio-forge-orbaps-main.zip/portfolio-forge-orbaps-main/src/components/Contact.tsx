
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Github, Linkedin, Instagram, Mail, Twitter } from "lucide-react";

export const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: ""
  });
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Message Sent!",
      description: "Thank you for reaching out. I'll get back to you soon.",
    });
    setFormData({ name: "", email: "", message: "" });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <section id="contact" className="py-20 px-4 bg-slate-800/30">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4">Get In Touch</h2>
          <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-purple-600 mx-auto mb-6"></div>
          <p className="text-slate-300 text-lg">
            Let's discuss space technology, defence projects, or web development opportunities
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-12">
          <div>
            <h3 className="text-2xl font-semibold text-white mb-6">Let's Connect</h3>
            <div className="space-y-6">
              <div className="flex items-center space-x-3 hover:transform hover:translate-x-2 transition-transform duration-300">
                <Mail className="text-red-500" size={20} />
                <div>
                  <h4 className="text-blue-400 font-medium">Email</h4>
                  <a href="mailto:amarendrapratapsingh.2004@gmail.com" className="text-slate-300 hover:text-white transition-colors">
                    amarendrapratapsingh.2004@gmail.com
                  </a>
                </div>
              </div>
              <div className="flex items-center space-x-3 hover:transform hover:translate-x-2 transition-transform duration-300">
                <Linkedin className="text-blue-500" size={20} />
                <div>
                  <h4 className="text-blue-400 font-medium">LinkedIn</h4>
                  <a href="https://www.linkedin.com/in/orbaps" target="_blank" rel="noopener noreferrer" className="text-slate-300 hover:text-blue-400 transition-colors">
                    linkedin.com/in/orbaps
                  </a>
                </div>
              </div>
              <div className="flex items-center space-x-3 hover:transform hover:translate-x-2 transition-transform duration-300">
                <Github className="text-slate-400" size={20} />
                <div>
                  <h4 className="text-blue-400 font-medium">GitHub</h4>
                  <a href="https://github.com/orbaps" target="_blank" rel="noopener noreferrer" className="text-slate-300 hover:text-white transition-colors">
                    github.com/orbaps
                  </a>
                </div>
              </div>
              <div>
                <h4 className="text-blue-400 font-medium mb-2">Location</h4>
                <p className="text-slate-300">India - Available for remote collaboration</p>
              </div>
            </div>
            
            <div className="mt-8">
              <h4 className="text-white font-medium mb-4">Follow Me</h4>
              <div className="flex space-x-4">
                <a href="https://www.linkedin.com/in/orbaps" target="_blank" rel="noopener noreferrer" 
                   className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center hover:bg-blue-700 transition-all duration-300 hover:scale-110">
                  <Linkedin size={20} className="text-white" />
                </a>
                <a href="https://github.com/orbaps" target="_blank" rel="noopener noreferrer"
                   className="w-12 h-12 bg-slate-700 rounded-full flex items-center justify-center hover:bg-slate-600 transition-all duration-300 hover:scale-110">
                  <Github size={20} className="text-white" />
                </a>
                <a href="https://www.instagram.com/orbaps/" target="_blank" rel="noopener noreferrer"
                   className="w-12 h-12 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full flex items-center justify-center hover:from-pink-600 hover:to-purple-700 transition-all duration-300 hover:scale-110">
                  <Instagram size={20} className="text-white" />
                </a>
                <a href="https://x.com/orbsingh?t=cK979IzVBXeWx5ploqldjQ&s=08" target="_blank" rel="noopener noreferrer"
                   className="w-12 h-12 bg-black rounded-full flex items-center justify-center hover:bg-slate-800 transition-all duration-300 hover:scale-110">
                  <Twitter size={20} className="text-white" />
                </a>
                <a href="https://www.threads.net/@orbaps" target="_blank" rel="noopener noreferrer"
                   className="w-12 h-12 bg-slate-600 rounded-full flex items-center justify-center hover:bg-slate-500 transition-all duration-300 hover:scale-110">
                  <span className="text-white font-bold text-sm">@</span>
                </a>
              </div>
            </div>
          </div>
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="name" className="block text-slate-300 mb-2">Name</label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-lg text-white placeholder-slate-400 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500 transition-colors"
                placeholder="Your name"
              />
            </div>
            <div>
              <label htmlFor="email" className="block text-slate-300 mb-2">Email</label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-lg text-white placeholder-slate-400 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500 transition-colors"
                placeholder="your.email@example.com"
              />
            </div>
            <div>
              <label htmlFor="message" className="block text-slate-300 mb-2">Message</label>
              <textarea
                id="message"
                name="message"
                value={formData.message}
                onChange={handleChange}
                required
                rows={5}
                className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-lg text-white placeholder-slate-400 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500 transition-colors resize-none"
                placeholder="Tell me about your project or collaboration idea..."
              ></textarea>
            </div>
            <button
              type="submit"
              className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white py-3 rounded-lg font-medium transition-all duration-300 transform hover:scale-105"
            >
              Send Message
            </button>
          </form>
        </div>
      </div>
    </section>
  );
};
