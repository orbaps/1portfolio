
export const About = () => {
  return (
    <section id="about" className="py-20 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4">About Me</h2>
          <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-purple-600 mx-auto"></div>
        </div>
        
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h3 className="text-2xl font-semibold text-white mb-6">
              Hello! I'm Amarendra Pratap Singh
            </h3>
            <p className="text-slate-300 mb-6 leading-relaxed">
              I'm a passionate student at Rashtriya Raksha University, where I'm developing specialized expertise 
              in Space & Defence technologies. My academic journey is complemented by practical experience as a 
              former intern at Indian Space Labs, where I gained invaluable insights into space technology and 
              aerospace engineering.
            </p>
            <p className="text-slate-300 mb-6 leading-relaxed">
              As a Full-Stack Developer and UI/UX Designer, I bridge the gap between technical functionality 
              and user experience. I've recently earned the SOLIDWORKS CAD Design Associate (CSWA) certification 
              from Dassault Systèmes, showcasing my proficiency in computer-aided design and engineering.
            </p>
            <p className="text-slate-300 mb-6 leading-relaxed">
              My educational foundation was built at St. Francis Higher Secondary School, where I developed 
              strong analytical and problem-solving skills. Today, I'm committed to contributing to India's 
              growing space and defense sector while creating innovative digital solutions.
            </p>
            
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-blue-400 font-medium">University:</span>
                <p className="text-slate-300">Rashtriya Raksha University</p>
              </div>
              <div>
                <span className="text-blue-400 font-medium">Primary Education:</span>
                <p className="text-slate-300">St. Francis Higher Secondary School</p>
              </div>
              <div>
                <span className="text-blue-400 font-medium">Certification:</span>
                <p className="text-slate-300">CSWA - SOLIDWORKS</p>
              </div>
              <div>
                <span className="text-blue-400 font-medium">Experience:</span>
                <p className="text-slate-300">Indian Space Labs (Intern)</p>
              </div>
            </div>
          </div>
          
          <div className="relative">
            <div className="bg-gradient-to-br from-blue-500/20 to-purple-600/20 rounded-2xl p-8 backdrop-blur-sm border border-slate-700/50">
              <h4 className="text-xl font-semibold text-white mb-6">What I Do</h4>
              <ul className="space-y-4">
                <li className="flex items-center text-slate-300">
                  <div className="w-3 h-3 bg-blue-500 rounded-full mr-4 animate-pulse"></div>
                  Space & Defence Technology Development
                </li>
                <li className="flex items-center text-slate-300">
                  <div className="w-3 h-3 bg-purple-500 rounded-full mr-4 animate-pulse delay-75"></div>
                  Full-Stack Web Development (React, Node.js)
                </li>
                <li className="flex items-center text-slate-300">
                  <div className="w-3 h-3 bg-pink-500 rounded-full mr-4 animate-pulse delay-150"></div>
                  UI/UX Design & Prototyping
                </li>
                <li className="flex items-center text-slate-300">
                  <div className="w-3 h-3 bg-cyan-500 rounded-full mr-4 animate-pulse delay-300"></div>
                  CAD Design & Engineering (SOLIDWORKS)
                </li>
                <li className="flex items-center text-slate-300">
                  <div className="w-3 h-3 bg-green-500 rounded-full mr-4 animate-pulse delay-500"></div>
                  Aerospace Engineering Applications
                </li>
              </ul>
            </div>

            {/* Floating achievement badges */}
            <div className="absolute -top-4 -right-4 bg-gradient-to-r from-yellow-400 to-orange-500 text-black px-3 py-1 rounded-full text-sm font-bold animate-bounce">
              CSWA Certified
            </div>
            <div className="absolute -bottom-4 -left-4 bg-gradient-to-r from-green-400 to-blue-500 text-white px-3 py-1 rounded-full text-sm font-bold animate-pulse">
              Space Tech
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
