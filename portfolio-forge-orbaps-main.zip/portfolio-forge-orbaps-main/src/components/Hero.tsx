
import { Github, Linkedin, Instagram, Mail, Twitter } from "lucide-react";

export const Hero = () => {
  return (
    <section id="home" className="min-h-screen flex items-center justify-center px-4 pt-16 relative overflow-hidden">
      {/* Enhanced animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-gradient-to-br from-blue-500/20 to-cyan-500/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-gradient-to-br from-purple-500/20 to-pink-500/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-gradient-to-br from-green-400/10 to-blue-500/10 rounded-full blur-3xl animate-pulse delay-2000"></div>
      </div>
      
      <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-12 items-center relative z-10">
        {/* Enhanced Avatar Section */}
        <div className="flex justify-center md:justify-end order-1 md:order-2">
          <div className="relative">
            <div className="w-80 h-80 bg-gradient-to-br from-blue-400 via-purple-500 to-pink-500 rounded-full p-1.5 animate-pulse shadow-2xl shadow-blue-500/30">
              <div className="w-full h-full bg-slate-900 rounded-full flex items-center justify-center overflow-hidden">
                {/* Enhanced AI Avatar */}
                <div className="w-72 h-72 bg-gradient-to-b from-amber-100 to-amber-200 rounded-full flex items-center justify-center relative shadow-inner">
                  {/* Face with better skin tone */}
                  <div className="absolute top-16 w-48 h-56 bg-gradient-to-b from-amber-200 to-amber-300 rounded-full shadow-lg">
                    {/* Eyes with enhanced animation */}
                    <div className="absolute top-16 left-12 w-5 h-5 bg-slate-800 rounded-full animate-blink shadow-sm">
                      <div className="absolute top-1 left-1 w-2 h-2 bg-white rounded-full opacity-70"></div>
                    </div>
                    <div className="absolute top-16 right-12 w-5 h-5 bg-slate-800 rounded-full animate-blink shadow-sm">
                      <div className="absolute top-1 left-1 w-2 h-2 bg-white rounded-full opacity-70"></div>
                    </div>
                    {/* Nose */}
                    <div className="absolute top-24 left-1/2 transform -translate-x-1/2 w-2 h-4 bg-amber-400 rounded-full shadow-sm"></div>
                    {/* Enhanced smile */}
                    <div className="absolute top-32 left-1/2 transform -translate-x-1/2 w-10 h-5 border-b-3 border-slate-800 rounded-full animate-bounce shadow-sm"></div>
                    {/* Eyebrows */}
                    <div className="absolute top-14 left-10 w-6 h-1 bg-slate-700 rounded-full"></div>
                    <div className="absolute top-14 right-10 w-6 h-1 bg-slate-700 rounded-full"></div>
                  </div>
                  {/* Enhanced hair - straight style */}
                  <div className="absolute top-6 w-56 h-28 bg-gradient-to-b from-slate-800 to-slate-700 rounded-t-full shadow-lg">
                    <div className="absolute top-2 left-4 w-48 h-6 bg-slate-800 rounded-full opacity-80"></div>
                    <div className="absolute top-4 left-8 w-40 h-4 bg-slate-700 rounded-full opacity-60"></div>
                  </div>
                </div>
              </div>
            </div>
            <div className="absolute -bottom-4 -right-4 w-24 h-24 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center animate-bounce shadow-xl">
              <span className="text-3xl animate-pulse">👋</span>
            </div>
            {/* Floating elements */}
            <div className="absolute -top-8 -left-8 w-16 h-16 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center animate-float shadow-lg">
              <span className="text-2xl">🚀</span>
            </div>
          </div>
        </div>

        {/* Enhanced Content Section */}
        <div className="text-center md:text-left order-2 md:order-1">
          <div className="animate-fade-in">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight font-playfair">
              <span className="bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 bg-clip-text text-transparent drop-shadow-lg">
                Amarendra Pratap Singh
              </span>
            </h1>
            <h2 className="text-xl md:text-2xl text-slate-300 mb-4 font-light font-inter">
              Rashtriya Raksha University Student
            </h2>
            <h3 className="text-lg md:text-xl text-blue-400 mb-4 font-medium font-inter">
              Bachelor of Technology in Electronics (VLSI) | Developing Expertise in Space & Defence
            </h3>
            <h4 className="text-base md:text-lg text-purple-400 mb-6 font-inter">
              Indian Space Labs Ex-Intern | Full-Stack Developer & UI/UX Designer
            </h4>
            <h5 className="text-sm md:text-base text-green-400 mb-8 font-inter flex items-center justify-center md:justify-start gap-2">
              <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
              CSWA Certified | 3D Printing Enthusiast
            </h5>
            
            {/* Enhanced Social Links */}
            <div className="flex justify-center md:justify-start gap-4 mb-8">
              <a href="https://github.com/orbaps" target="_blank" rel="noopener noreferrer" 
                 className="w-14 h-14 bg-slate-800 hover:bg-slate-700 rounded-full flex items-center justify-center transition-all duration-300 hover:scale-110 hover:shadow-xl hover:shadow-slate-500/30 group">
                <Github size={22} className="text-white group-hover:text-blue-400 transition-colors" />
              </a>
              <a href="https://www.linkedin.com/in/orbaps" target="_blank" rel="noopener noreferrer"
                 className="w-14 h-14 bg-blue-600 hover:bg-blue-700 rounded-full flex items-center justify-center transition-all duration-300 hover:scale-110 hover:shadow-xl hover:shadow-blue-500/30">
                <Linkedin size={22} className="text-white" />
              </a>
              <a href="https://www.instagram.com/orbaps/" target="_blank" rel="noopener noreferrer"
                 className="w-14 h-14 bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 rounded-full flex items-center justify-center transition-all duration-300 hover:scale-110 hover:shadow-xl hover:shadow-pink-500/30">
                <Instagram size={22} className="text-white" />
              </a>
              <a href="https://x.com/orbsingh?t=cK979IzVBXeWx5ploqldjQ&s=08" target="_blank" rel="noopener noreferrer"
                 className="w-14 h-14 bg-slate-900 hover:bg-black rounded-full flex items-center justify-center transition-all duration-300 hover:scale-110 hover:shadow-xl hover:shadow-slate-500/30">
                <Twitter size={22} className="text-white" />
              </a>
              <a href="https://www.threads.net/@orbaps" target="_blank" rel="noopener noreferrer"
                 className="w-14 h-14 bg-slate-700 hover:bg-slate-800 rounded-full flex items-center justify-center transition-all duration-300 hover:scale-110 hover:shadow-xl hover:shadow-slate-500/30">
                <span className="text-white font-bold text-lg">@</span>
              </a>
              <a href="mailto:amarendrapratapsingh.2004@gmail.com"
                 className="w-14 h-14 bg-red-600 hover:bg-red-700 rounded-full flex items-center justify-center transition-all duration-300 hover:scale-110 hover:shadow-xl hover:shadow-red-500/30">
                <Mail size={22} className="text-white" />
              </a>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
              <button 
                onClick={() => document.querySelector('#projects')?.scrollIntoView({ behavior: 'smooth' })}
                className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-8 py-4 rounded-xl font-medium transition-all duration-300 transform hover:scale-105 hover:shadow-xl hover:shadow-blue-500/30 font-inter"
              >
                View My Work
              </button>
              <button 
                onClick={() => document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' })}
                className="border-2 border-slate-600 text-slate-300 hover:border-blue-500 hover:text-white hover:bg-blue-500/10 px-8 py-4 rounded-xl font-medium transition-all duration-300 transform hover:scale-105 backdrop-blur-sm font-inter"
              >
                Get In Touch
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
